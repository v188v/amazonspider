import scrapy


class Amazon(scrapy.Spider):
    name = "amazon"
    start_urls = [
        'https://www.amazon.com/Best-Sellers-Pet-Supplies/zgbs/pet-supplies/ref=zg_bs_pg_1?_encoding=UTF8&pg=1',
    ]

    def parse(self, response):
        for items in response.xpath('//*[@id="zg-ordered-list"]/li/span/div/span'):
            yield {
                'img': items.xpath('./a/span/div/img/@src').extract(),
                #'title': quote.xpath('span/small/text()').extract_first(),
            }

        next_page = response.xpath('//*[@id="zg-center-div"]/div[2]/div/ul/li[4]/a/@href').extract_first()
        if next_page is not None:
            yield response.follow(next_page, self.parse)